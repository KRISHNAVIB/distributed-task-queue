package com.example.dtq.service;

import com.example.dtq.controller.JobRequest;
import com.example.dtq.model.Job;
import com.example.dtq.repository.JobRepository;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class JobService {
    private final JobRepository repo;

    public JobService(JobRepository repo)
    {
        this.repo = repo;
    }

    public ResponseEntity<?> submitJob(JobRequest request){
        String tenantId=request.getTenantId();
        if(tenantId==null|tenantId.isEmpty()){
            return ResponseEntity.badRequest().body("tenantId is Required");
        }

        String rateKey=rateKey(tenantId);
        Long rateCount=repo.incrementCounterWithExpiry(rateKey,60);

        if(rateCount>10) {
            return ResponseEntity.status(429).body("Rate limit exceeded(10jobs/min)");
        }

        String activeKey=activeJobKey(tenantId);
        Long activeJobs=repo.getOrDefault(activeKey,0L);

        if(activeJobs>=5){
            return ResponseEntity.status(429).body("Max 5 concurrent jobs");

        }

        Job job =new Job(tenantId, request.getPayloadJson(), request.getMaxRetries());
        repo.saveJob(job);
        repo.pushToPendingQueue(job.getId());
        repo.incrementCounter(activeKey);
        return ResponseEntity.ok(job.getId());
    }

    public ResponseEntity<?> getJobStatus(String jobId) {
        var map=repo.getAllJobFields(jobId);
        if(map==null || map.isEmpty()) {
            return ResponseEntity.status(404).body("Job not found");
        }
        return ResponseEntity.ok().body(map);
    }

    private String rateKey(String tenantId){
        return "tenant:" + tenantId +":rate";
    }

    private String activeJobKey(String tenantId){
        return "tenant:"+ tenantId +":active_jobs";
    }

    public ResponseEntity<?> getPendingJobs(){
        return ResponseEntity.ok(repo.getPendingJobs());
    }

    public ResponseEntity<?> getRunningJobs(){
        return ResponseEntity.ok(repo.getRunningJobs());
    }

    public ResponseEntity<?> getCompletedJobs(){
        return ResponseEntity.ok(repo.getCompletedJobs());
    }

    public ResponseEntity<?> getDLQJobs(){
        return ResponseEntity.ok(repo.getDLQJobs());
    }
}
