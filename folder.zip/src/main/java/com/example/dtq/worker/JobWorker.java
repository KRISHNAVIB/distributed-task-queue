package com.example.dtq.worker;

import com.example.dtq.model.JobStatus;
import com.example.dtq.repository.JobRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class JobWorker {

    private final JobRepository repo;

    public JobWorker(JobRepository repo) {
        this.repo = repo;
    }

    @Scheduled(fixedDelay = 2000)
    public void pollAndProcess(){
        String jobId=repo.popNextPendingJob();

        if(jobId==null)
        {
            log.info("No Jobs in queue");
            return;
        }
        log.info("Picked Job from queue: {}",jobId);

        boolean leaseAcquired=repo.acquireLease(jobId,"worker-1",30L);
        if(!leaseAcquired){
            log.info("Could not acquire lease for Job: {} - another worker is processing",jobId);
            return;
        }
        log.info("Lease acquired for job: {}",jobId);

        repo.markJobRunning(jobId);
        log.info("Marked job as RUNNING: {}",jobId);

        try{
            log.info("Processing job: {}",jobId);

            Thread.sleep(30000);
            boolean success=true;

            if(success){
                log.info("Job Processed successfully: {}",jobId);
                handleSuccess(jobId);
            }
            else{
                throw new RuntimeException("Simulated Failure");
            }
        } catch (Exception e) {
            log.error("Error while processing job{} - {}",jobId,e.getMessage());
            handleFailure(jobId,e.getMessage());
        }

    }
    private void handleSuccess(String jobId)
    {
        repo.markJobCompleted(jobId);
        repo.saveLastError(jobId, "");
        repo.removeFromRunningSet(jobId);
        repo.removeLease(jobId);
        log.info("Job COMPLETED successfully: {}",jobId);
    }

    private void handleFailure(String jobId,String errorMessage){
        int retries=repo.incrementRetries(jobId);

        Object maxRetryObj=repo.getJobField(jobId,"maxRetries");
        int maxRetries=maxRetryObj!=null?Integer.parseInt(maxRetryObj.toString()):3;
        repo.saveLastError(jobId,errorMessage);

        if(retries<maxRetries){
            repo.updateJobStatus(jobId, JobStatus.PENDING);
            repo.pushToPendingQueue(jobId);

            log.warn("Retrying job {} (attempt {}/{})",jobId,retries,maxRetries);
        }
        else{
            repo.moveToDLQ(jobId);
            log.error("job {} moved to DLQ after {} retries",jobId,retries);
        }


        repo.removeFromRunningSet(jobId);
        repo.removeLease(jobId);
    }
}
