package com.example.dtq.controller;

import com.example.dtq.service.JobService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/jobs")
public class JobController {

    private final JobService jobService;

    public JobController(JobService jobService){
        this.jobService=jobService;
    }

    @PostMapping
    public ResponseEntity<?> submitJob(@RequestBody JobRequest request){
        return jobService.submitJob(request);
    }

    @GetMapping("/{jobId}")
    public ResponseEntity<?> getJobStatus(@PathVariable String jobId){
        return jobService.getJobStatus(jobId);
    }

    @GetMapping("/pending")
    public ResponseEntity<?> getPending(){
        return ResponseEntity.ok(jobService.getPendingJobs());
    }

    @GetMapping("/running")
    public ResponseEntity<?> getRunning(){
        return ResponseEntity.ok(jobService.getRunningJobs());
    }
    @GetMapping("/completed")
    public ResponseEntity<?> getCompleted(){
        return ResponseEntity.ok(jobService.getCompletedJobs());
    }

    @GetMapping("/dlq")
    public ResponseEntity<?> getDLQ(){
        return ResponseEntity.ok(jobService.getDLQJobs());
    }

    @GetMapping("/test")
    public String test() {
        return "controller working";
    }

}
