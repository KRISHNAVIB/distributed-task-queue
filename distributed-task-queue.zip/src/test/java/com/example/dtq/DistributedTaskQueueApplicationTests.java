package com.example.dtq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedTaskQueueApplicationTests {

	@Test
	void contextLoads() {
	}

}
